public class Main {

    public static void main(String[] args)
    {
	double salesPrice = 10;
	double salesTax = 0.05;
	double taxTotal;

	taxTotal = salesPrice * salesTax;

	System.out.println("The sales tax is $" + taxTotal + " on a $" + salesPrice + " item.");
    }
}
